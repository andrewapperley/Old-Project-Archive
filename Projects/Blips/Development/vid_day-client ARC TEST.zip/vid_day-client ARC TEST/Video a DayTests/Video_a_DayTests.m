//
//  Video_a_DayTests.m
//  Video a DayTests
//
//  Created by Andrew Apperley on 2013-09-10.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Video_a_DayTests : XCTestCase

@end

@implementation Video_a_DayTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
