//
//  Constants.h
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-11.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MAIN_SCREEN_SIZE \
    CGSizeMake([[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height)
#define UserDefaults                        [NSUserDefaults standardUserDefaults]
#define NotificationCenter                  [NSNotificationCenter defaultCenter]
#define Bundle                              [NSBundle mainBundle]
#define MainScreen                          [UIScreen mainScreen]
#define ScreenWidth                         [[UIScreen mainScreen] bounds].size.width
#define ScreenHeight                        [[UIScreen mainScreen] bounds].size.height
#define IS_IPHONE5 ScreenHeight == 568
#define SystemVersion                       [[UIDevice currentDevice].systemVersion floatValue]
#define DEGREES_TO_RADIANS(x)               (M_PI * x / 180.0)
#define RGB(r, g, b)                        [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]
#define RGBA(r, g, b, a)                    [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define HEXCOLOR(c, a)                      [UIColor colorWithRed:((c>>16)&0xFF)/255.0 green:((c>>8)&0xFF)/255.0 blue:(c&0xFF)/255.0 alpha:a]
#define AFFLogObject(o,m)                     NSLog(@"\nLog Message: %@\nFunction: %s \nLine: %d \nObject:%@",m, __func__, __LINE__, o)
#define AFFLog(m)                            NSLog(@"\nLog Message: %@\nFunction: %s \nLine: %d",m, __func__, __LINE__)

//Center an object relative to it's container
#define CENTER_OBJECT_X($object, $container)                                                \
[$object setAffX:($container.bounds.size.width - $object.bounds.size.width) / 2 ]

#define CENTER_OBJECT_Y($object, $container)                                                \
[$object setAffY:($container.bounds.size.height - $object.bounds.size.height) / 2 ]

#define CENTER_OBJECT($object, $container)                                                  \
[$object setAffX:($container.bounds.size.width - $object.bounds.size.width) / 2 ];      \
[$object setAffY:($container.bounds.size.height - $object.bounds.size.height) / 2 ]

#define destroy($x)                                             \
if($x)                                                          \
{                                                               \
}                                                               \

#define destroyAndRemove($x)                                    \
if($x)                                                          \
{                                                               \
[$x removeFromSuperview];                                   \
}

#define removeAllSubviews($x)                                   \
if($x && $x.subviews.count > 0)                                 \
{                                                               \
while ($x.subviews.count > 0)                               \
[[$x.subviews objectAtIndex:0] removeFromSuperview];    \
}                                                       \

extern NSString *const MAIN_FONT;
extern NSString *const BOLD_FONT;
extern NSString *const BASE_URL;
extern int HEADER_HEIGHT;