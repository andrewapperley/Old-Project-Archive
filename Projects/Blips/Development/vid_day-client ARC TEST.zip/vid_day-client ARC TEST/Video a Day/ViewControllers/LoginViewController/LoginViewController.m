//
//  LoginViewController.m
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-11.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import "LoginViewController.h"
#import "SignupViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (id)init
{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        self.title = @"Login";
        self.navigationItem.titleView = [[UIView alloc] init];
        self.navigationItem.hidesBackButton = true;
        self.view = [[LoginView alloc] initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_SIZE.width, MAIN_SCREEN_SIZE.height)];
        [[((LoginView *)self.view) evtLoginButtonPressed] addHandler:AFFHandler(@selector(loginButtonPressed:))];
        [[((LoginView *)self.view) evtSignupButtonPressed] addHandler:AFFHandler(@selector(signupButtonPressed))];
    }
    return self;
}

- (void)dealloc
{
    [[((LoginView *)self.view) evtLoginButtonPressed] removeHandler:AFFHandler(@selector(loginButtonPressed:))];
    [[((LoginView *)self.view) evtSignupButtonPressed] removeHandler:AFFHandler(@selector(signupButtonPressed))];
    
    destroyAndRemove(self.view);
    AFFRemoveAllEvents();
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:true animated:true];
}


- (void)loginButtonPressed:(AFFEvent *)event
{
    if([event.data[0] isEqual:[NSNull null]] || [event.data[0] isEqualToString:@""] || [event.data[1] isEqual:[NSNull null]] || [event.data[1] isEqualToString:@""]) {
        [[VDDialogViewController sharedManager] addAndOpenViewWithViewController:self andSize:CGSizeMake(270, 189) andTitle:@"Login Error" andText:@"Please provide a username and password" andButtons:[NSArray arrayWithObject:@"Okay"]];
        return;
    }
    
    AFFNRequest *request = [AFFNRequest requestWithConnectionType:kAFFNPost andURL:[BASE_URL stringByAppendingString:@"hello"] andParams:[NSDictionary dictionaryWithObjectsAndKeys:event.data[0], @"username", event.data[1], @"password", nil] withCompletion:^(AFFNCallbackObject *result){
        NSJSONSerialization *resultString = [NSJSONSerialization JSONObjectWithData:result.data options:NSJSONReadingAllowFragments error:nil];
        NSLog(@"%@",resultString);
        
    } andFailure:^(NSError *error){
        NSLog(@"Error: %@",error);
    }];
    
    [[AFFNManager sharedManager] addNetworkOperation:request];
}

- (void)signupButtonPressed
{
    SignupViewController *signupVC = [[SignupViewController alloc] init];
    [self.navigationController pushViewController:signupVC animated:true];
    destroy(signupVC);
}

- (BOOL)prefersStatusBarHidden
{
    return true;
}

@end