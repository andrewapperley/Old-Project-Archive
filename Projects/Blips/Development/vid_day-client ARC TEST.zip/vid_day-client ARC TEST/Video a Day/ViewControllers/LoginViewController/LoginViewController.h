//
//  LoginViewController.h
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-11.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginView.h"
@interface LoginViewController : UIViewController

@end
