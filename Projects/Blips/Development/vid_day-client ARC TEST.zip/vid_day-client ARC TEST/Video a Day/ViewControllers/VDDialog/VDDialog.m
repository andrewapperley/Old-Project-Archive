//
//  VDDialog.m
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-11.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import "VDDialog.h"
#import <QuartzCore/QuartzCore.h>
@implementation VDDialog

AFFEventSynthesize(AFFEventInstance, evtButtonPressed);

- (id)initWithSize:(CGSize)lsize andTitle:(NSString *)ltitle andText:(NSString *)ltext andButtons:(NSArray *)lbuttons
{
    self = [super initWithFrame:CGRectMake(0, 0, lsize.width, lsize.height)];
    if (self) {
        self.clipsToBounds = true;
        self.backgroundColor = [UIColor whiteColor];
        self.layer.cornerRadius = 5;
        self.layer.opacity = 0.84f;
        [self setupTitle:ltitle];
        if(ltext)
            [self setupText:ltext];
        else
            [self setupInputBox];
        [self setupButtons:lbuttons];
    }
    return self;
}

- (void)setupTitle:(NSString *)ltitle
{
    UILabel *title = [[UILabel alloc] init];
    title.text = ltitle;
    title.font = [UIFont fontWithName:BOLD_FONT size:18];
    title.backgroundColor = [UIColor clearColor];
    title.textAlignment = NSTextAlignmentCenter;
    title.affWidth = self.affWidth - 10;
    title.affHeight = 20;
    CENTER_OBJECT_X(title, self);   
    title.affY = 20;
    
    [self addSubview:title];
    destroy(title);
}

- (void)setupInputBox
{
    textField = [[UITextField alloc] init];
    textField.layer.borderColor = [RGBA(1, 203, 117, 0.7f) CGColor];
    [textField setReturnKeyType:UIReturnKeyDone];
    textField.layer.borderWidth = 1;
    textField.delegate = self;
    textField.affHeight = 20;
    textField.affWidth = self.affWidth - 30;
    CENTER_OBJECT(textField, self);
    [self addSubview:textField];
}

- (BOOL)textFieldShouldReturn:(UITextField *)ltextField
{
    [textField resignFirstResponder];
    return true;
}

- (void)setupText:(NSString *)ltext
{
    UILabel *text = [[UILabel alloc] init];
    text.text = ltext;
    text.font = [UIFont fontWithName:MAIN_FONT size:15];
    text.numberOfLines = 10;
    text.lineBreakMode = NSLineBreakByWordWrapping;
    text.backgroundColor = [UIColor clearColor];
    text.textAlignment = NSTextAlignmentCenter;
    text.affWidth = self.affWidth - 30;
    text.frame = [ltext boundingRectWithSize:CGSizeMake(text.affWidth, CGFLOAT_MAX) options:(NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading)attributes:[NSDictionary dictionaryWithObject:text.font forKey:NSFontAttributeName] context:nil];
    CENTER_OBJECT(text, self);
    
    [self addSubview:text];
    destroy(text);
}

- (void)setupButtons:(NSArray *)lbuttons
{
    NSMutableArray *buttons = [[NSMutableArray alloc] initWithCapacity:2];
    for (NSString *b in lbuttons) {
        UIButton *button = [UIButton new];
        button.tag = buttons.count + 1;
        [button addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
        button.affWidth = (lbuttons.count == 2) ? self.affWidth/2 : self.affWidth;
        button.affHeight = self.affHeight* 0.233f;
        [button setTitle:b forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
        button.affY = self.affHeight - button.affHeight + 1;
        button.affX = buttons.count > 0 ? button.affWidth : 0;
        [button setBackgroundImage:[self imageWithColor:RGBA(255, 255, 255, 0.7f) andSize:button.frame.size] forState:UIControlStateNormal];
        [button setBackgroundImage:[self imageWithColor:RGBA(1, 203, 117, 0.7f) andSize:button.frame.size] forState:UIControlStateHighlighted];
        [buttons addObject:button];
        [self addSubview:button];
        button = nil;
    }
    buttons = nil;
}

- (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)lsize
{
    CGRect rect = CGRectMake(0.0f, 0.0f, lsize.width, lsize.height);
    UIGraphicsBeginImageContextWithOptions(rect.size, false, 1);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

- (void)buttonPressed:(UIButton *)b
{
    [[self evtButtonPressed] send:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:(int)b.tag], @"buttonIndex", textField.text, @"textInput", nil]];
}

- (void)dealloc
{
    AFFRemoveAllEvents();
    
    textField.delegate = nil;
    textField = nil;
    
}

@end
