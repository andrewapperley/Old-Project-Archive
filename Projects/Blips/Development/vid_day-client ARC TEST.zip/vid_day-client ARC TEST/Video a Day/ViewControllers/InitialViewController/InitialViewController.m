//
//  InitialViewController.m
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-11.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import "InitialViewController.h"


@implementation InitialViewController

- (id)init
{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"";
    self.navigationController.navigationBarHidden = true;
    self.navigationController.navigationBar.tintColor = RGB(255, 255, 255);
    self.navigationController.navigationBar.barTintColor = RGB(0, 202, 116);
    [self loadLoginView];
}


- (void)loadLoginView
{
    LoginViewController *lvc = [[LoginViewController alloc] init];
    [self.navigationController pushViewController:lvc animated:true];
    lvc = nil;
}

- (void)loadTimeLineView
{
    
}

- (BOOL)prefersStatusBarHidden
{
    return true;
}


@end
