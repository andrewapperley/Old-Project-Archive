//
//  LoginView.h
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-14.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginView : UIView<UITextFieldDelegate>
{
    UIScrollView *scrollView;
    UIImageView *logo;
    UITextField *usernameField;
    UITextField *passwordField;
    
    UIButton *loginButton;
    UIButton *signupButton;
    UIImage *buttonImage;
}

AFFEventCreate(AFFEventInstance, evtLoginButtonPressed);
AFFEventCreate(AFFEventInstance, evtSignupButtonPressed);
@end