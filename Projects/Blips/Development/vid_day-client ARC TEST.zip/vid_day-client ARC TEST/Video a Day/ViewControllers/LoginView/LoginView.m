//
//  LoginView.m
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-14.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import "LoginView.h"

@implementation LoginView

AFFEventSynthesize(AFFEventInstance, evtLoginButtonPressed);
AFFEventSynthesize(AFFEventInstance, evtSignupButtonPressed);

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (void)setupUI
{
    scrollView = [[UIScrollView alloc] initWithFrame:self.frame];
    scrollView.scrollEnabled = false;
    scrollView.contentSize = CGSizeMake(self.affWidth, self.affHeight + 150);
    
    self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:IS_IPHONE5 ? @"genericBackground-568h.jpg" : @"genericBackground.jpg"]];
    
    logo = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo.png"]];
    CENTER_OBJECT_X(logo, self);
    
    UIView *padding = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 17, 40)];
    
    usernameField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 284, 40)];
    usernameField.leftView = padding;
    usernameField.leftViewMode = UITextFieldViewModeAlways;
    usernameField.font = [UIFont fontWithName:BOLD_FONT size:16];
    usernameField.backgroundColor = RGBA(255, 255, 255, 0.9);
    usernameField.placeholder = @"username";
    CENTER_OBJECT_X(usernameField, self);
    usernameField.affY = IS_IPHONE5 ? 332 : 240;
    usernameField.delegate = self;
    
    logo.affY = (usernameField.affY - logo.affHeight) / 2;
    
    passwordField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 284, 40)];
    passwordField.secureTextEntry = true;
    passwordField.leftView = padding;
    passwordField.rightView = padding;
    passwordField.leftViewMode = UITextFieldViewModeAlways;
    passwordField.font = [UIFont fontWithName:BOLD_FONT size:16];
    passwordField.backgroundColor = RGBA(255, 255, 255, 0.9);
    passwordField.placeholder = @"password";
    CENTER_OBJECT_X(passwordField, self);
    passwordField.affY = usernameField.affHeight + usernameField.affY + 17;
    passwordField.delegate = self;
    
    destroy(padding);
    
    buttonImage = [[UIImage imageNamed:@"largeButton.png"] copy];
    loginButton = [[UIButton alloc] initWithFrame:CGRectMake(0, passwordField.affHeight + passwordField.affY + 17, buttonImage.size.width, buttonImage.size.height)];
    [loginButton setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [loginButton setBackgroundImage:[UIImage imageNamed:@"largeButton_c.png"] forState:UIControlStateHighlighted];
    [loginButton setTitle:@"Login" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    CENTER_OBJECT_X(loginButton, self);
    [loginButton addTarget:self action:@selector(loginButtonPressed) forControlEvents:UIControlEventTouchUpInside];
    
    signupButton = [[UIButton alloc] initWithFrame:CGRectMake(0, loginButton.affHeight + loginButton.affY + 17, buttonImage.size.width, buttonImage.size.height)];
    NSLog(@"%f",signupButton.affY);
    [signupButton setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [signupButton setBackgroundImage:[UIImage imageNamed:@"largeButton_c.png"] forState:UIControlStateHighlighted];
    [signupButton setTitle:@"Sign up" forState:UIControlStateNormal];
    [signupButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    CENTER_OBJECT_X(signupButton, self);
    [signupButton addTarget:self action:@selector(signupButtonPressed) forControlEvents:UIControlEventTouchUpInside];
    
    loginButton.titleLabel.font = signupButton.titleLabel.font = [UIFont fontWithName:BOLD_FONT size:16];
    
    [self addSubview:logo];
    [self addSubview:scrollView];
    [scrollView addSubview:usernameField];
    [scrollView addSubview:passwordField];
    [scrollView addSubview:loginButton];
    [scrollView addSubview:signupButton];
}

- (void)loginButtonPressed
{
    [[self evtLoginButtonPressed] send:[NSArray arrayWithObjects:usernameField.text, passwordField.text, nil]];
}

- (void)signupButtonPressed
{
    [[self evtSignupButtonPressed] send];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [scrollView setContentOffset:CGPointMake(0, 0) animated:true];
    [textField resignFirstResponder];
    return true;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [scrollView setContentOffset:CGPointMake(0, 82) animated:true];
}

- (void)dealloc
{
    AFFRemoveAllEvents();
    removeAllSubviews(self);
    
    destroy(logo);
    destroy(usernameField);
    destroy(passwordField);
    destroy(loginButton);
    destroy(signupButton);
    destroy(scrollView);
    if(buttonImage)
        destroy(buttonImage);
    
}

@end