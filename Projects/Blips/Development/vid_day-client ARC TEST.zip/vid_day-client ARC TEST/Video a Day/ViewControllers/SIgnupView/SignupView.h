//
//  SignupView.h
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-18.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignupView : UIView<UITextFieldDelegate>
{
    UIView *profileImageContainer;
    UILabel *selectProfilePictureText;
    UIImage *buttonImage;
}


@property(nonatomic, strong)UITextField *usernameField;
@property(nonatomic, strong)UITextField *passwordField;
@property(nonatomic, strong)UITextField *repeatPasswordField;
@property(nonatomic, strong)UITextField *emailField;

@property(nonatomic, strong)UIButton *profileImage;
@property(nonatomic, strong)UIButton *submitButton;
@property(nonatomic, strong)UIImage *profilePicture;
@property(nonatomic, strong)UIView *overlayView;
@property(nonatomic, strong)UIScrollView *scrollView;

AFFEventCreate(AFFEventInstance, evtSignupButtonPressed);
@end