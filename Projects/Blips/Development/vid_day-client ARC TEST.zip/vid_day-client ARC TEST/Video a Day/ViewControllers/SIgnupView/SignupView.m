//
//  SignupView.m
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-18.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import "SignupView.h"

@implementation SignupView

AFFEventSynthesize(AFFEventInstance, evtSignupButtonPressed);

@synthesize usernameField = _usernameField, passwordField = _passwordField, repeatPasswordField = _repeatPasswordField, emailField = _emailField, profileImage = _profileImage, submitButton = _submitButton, overlayView = _overlayView, scrollView = _scrollView;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return self;
}

- (void)setupUI
{
    
    self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:IS_IPHONE5 ? @"genericBackground-568h.jpg" : @"genericBackground.jpg"]];
    
    _overlayView = [[UIView alloc] initWithFrame:self.frame];
    _overlayView.backgroundColor = [UIColor blackColor];
    _overlayView.alpha = 0;
    _overlayView.userInteractionEnabled = true;
    
    _scrollView = [[UIScrollView alloc] initWithFrame:self.frame];
    _scrollView.scrollEnabled = false;
    _scrollView.contentSize = CGSizeMake(self.affWidth, self.affHeight + 250);
    
    _profileImage = [[UIButton alloc] init];
    [_profileImage.imageView setContentMode:UIViewContentModeScaleToFill];
    [_profileImage setImage:[UIImage imageNamed:@"profilePictureDefault.png"]  forState:UIControlStateNormal];
    [_profileImage setImage:[UIImage imageNamed:@"profilePictureDefault_c.png"]  forState:UIControlStateHighlighted];
    
    profileImageContainer = [[UIView alloc] initWithFrame:CGRectMake(18.5, 0, _profileImage.imageView.image.size.width + 10, _profileImage.imageView.image.size.height + 10)];
    profileImageContainer.backgroundColor = RGBA(255, 255, 255, 0.9f);
    _profileImage.frame = CGRectMake(5, 5, _profileImage.imageView.image.size.width, _profileImage.imageView.image.size.height);
    
    selectProfilePictureText = [[UILabel alloc] initWithFrame:CGRectMake(profileImageContainer.affX, 0, 229, 17)];
    selectProfilePictureText.backgroundColor = [UIColor clearColor];
    selectProfilePictureText.font = [UIFont fontWithName:BOLD_FONT size:15];
    selectProfilePictureText.textColor = RGB(40, 40, 40);
    selectProfilePictureText.text = @"press to select photo";
    
    UIView *padding = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 17, 40)];
    
    _usernameField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 284, 40)];
    _usernameField.leftView = padding;
    _usernameField.leftViewMode = UITextFieldViewModeAlways;
    _usernameField.font = [UIFont fontWithName:BOLD_FONT size:16];
    _usernameField.backgroundColor = RGBA(255, 255, 255, 0.9);
    _usernameField.placeholder = @"username";
    CENTER_OBJECT_X(_usernameField, self);
    _usernameField.delegate = self;
    
    _passwordField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 284, 40)];
    _passwordField.leftView = padding;
    _passwordField.rightView = padding;
    _passwordField.leftViewMode = UITextFieldViewModeAlways;
    _passwordField.secureTextEntry = true;
    _passwordField.font = [UIFont fontWithName:BOLD_FONT size:16];
    _passwordField.backgroundColor = RGBA(255, 255, 255, 0.9);
    _passwordField.placeholder = @"password";
    CENTER_OBJECT_X(_passwordField, self);
    _passwordField.delegate = self;
    
    _repeatPasswordField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 284, 40)];
    _repeatPasswordField.leftView = padding;
    _repeatPasswordField.rightView = padding;
    _repeatPasswordField.leftViewMode = UITextFieldViewModeAlways;
    _repeatPasswordField.secureTextEntry = true;
    _repeatPasswordField.font = [UIFont fontWithName:BOLD_FONT size:16];
    _repeatPasswordField.backgroundColor = RGBA(255, 255, 255, 0.9);
    _repeatPasswordField.placeholder = @"repeat password";
    CENTER_OBJECT_X(_repeatPasswordField, self);
    _repeatPasswordField.delegate = self;
    
    _emailField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 284, 40)];
    _emailField.leftView = padding;
    _emailField.rightView = padding;
    _emailField.leftViewMode = UITextFieldViewModeAlways;
    _emailField.font = [UIFont fontWithName:BOLD_FONT size:16];
    _emailField.backgroundColor = RGBA(255, 255, 255, 0.9);
    _emailField.placeholder = @"email";
    CENTER_OBJECT_X(_emailField, self);
    _emailField.delegate = self;
    
    destroy(padding);
    
    _usernameField.autocapitalizationType = _passwordField.autocapitalizationType = _repeatPasswordField.autocapitalizationType = _emailField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    
    _usernameField.autocorrectionType = _passwordField.autocorrectionType = _repeatPasswordField.autocorrectionType = _emailField.autocorrectionType = UITextAutocorrectionTypeNo;
    
    _emailField.keyboardType = UIKeyboardTypeEmailAddress;
    
    buttonImage = [[UIImage imageNamed:@"largeButton.png"] copy];
    _submitButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, buttonImage.size.width, buttonImage.size.height)];
    [_submitButton setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [_submitButton setBackgroundImage:[UIImage imageNamed:@"largeButton_c.png"] forState:UIControlStateHighlighted];
    [_submitButton setTitle:@"Sign up" forState:UIControlStateNormal];
    [_submitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    CENTER_OBJECT_X(_submitButton, self);
    [_submitButton addTarget:self action:@selector(signupButtonPressed) forControlEvents:UIControlEventTouchUpInside];
    
    _submitButton.titleLabel.font = [UIFont fontWithName:BOLD_FONT size:16];
    
    destroy(buttonImage);
    
    //Align all the view's affY
    _submitButton.affY = IS_IPHONE5 ? 463.5 : 371.5;
    _emailField.affY = _submitButton.affY - _submitButton.affHeight - 15;
    _repeatPasswordField.affY = _emailField.affY - _emailField.affHeight - 15;
    _passwordField.affY = _repeatPasswordField.affY - _repeatPasswordField.affHeight - 15;
    _usernameField.affY = _passwordField.affY - _passwordField.affHeight - 15;
    selectProfilePictureText.affY = _usernameField.affY - selectProfilePictureText.affHeight - 15;
    profileImageContainer.affY = selectProfilePictureText.affY - profileImageContainer.affHeight - 15;
    
    
    [self addSubview:_scrollView];
    [self addSubview:_overlayView];
    [_scrollView addSubview:profileImageContainer];
    [profileImageContainer addSubview:_profileImage];
    [_scrollView addSubview:selectProfilePictureText];
    
    [_scrollView addSubview:_usernameField];
    [_scrollView addSubview:_passwordField];
    [_scrollView addSubview:_repeatPasswordField];
    [_scrollView addSubview:_emailField];
    [_scrollView addSubview:_submitButton];
    
    
    destroy(profileImageContainer);
    destroy(selectProfilePictureText);
    
}

- (void)signupButtonPressed
{
    [[self evtSignupButtonPressed] send];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [_scrollView setContentOffset:CGPointMake(0, -HEADER_HEIGHT/2) animated:true];
    [textField resignFirstResponder];
    return true;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    int offset = 0;
    
    if([textField isEqual:_usernameField])
        offset = 20;
    else if ([textField isEqual:_passwordField])
        offset = 50;
    else if ([textField isEqual:_repeatPasswordField] || [textField isEqual:_emailField])
        offset = 100;
    
    [_scrollView setContentOffset:CGPointMake(0, offset) animated:true];
}


- (void)dealloc
{
    
    self.usernameField.delegate = nil;
    self.passwordField.delegate = nil;
    self.repeatPasswordField.delegate = nil;
    self.emailField.delegate = nil;
    
    AFFRemoveAllEvents();
    
    destroyAndRemove(_usernameField);
    destroyAndRemove(_passwordField);
    destroyAndRemove(_repeatPasswordField);
    destroyAndRemove(_emailField);
    destroyAndRemove(_profileImage);
    destroyAndRemove(_submitButton);
    destroyAndRemove(_scrollView);
    destroyAndRemove(_overlayView);
    
    if(buttonImage)
        destroy(buttonImage);

    
}

@end