//
//  SignupViewController.m
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-14.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import "SignupViewController.h"
#import "SignupView.h"

@implementation SignupViewController

- (void)viewDidLoad
{
    self.view = [[SignupView alloc] initWithFrame:self.view.frame];
    
    [[(SignupView *)self.view evtSignupButtonPressed] addHandler:AFFHandler(@selector(signupPressed))];
    [((SignupView *)self.view).profileImage addTarget:self action:@selector(profileImagePressed) forControlEvents:UIControlEventTouchUpInside];
    
	[self.navigationController setNavigationBarHidden:false animated:true];
    
    [super viewDidLoad];
}

- (void)dealloc
{
    [[(SignupView *)self.view evtSignupButtonPressed] removeHandlersForObserver:self];
    [((SignupView *)self.view).profileImage removeTarget:self action:@selector(profileImagePressed) forControlEvents:UIControlEventTouchUpInside];
    destroy(profileImage);
    [self setView:nil];
    
    
}

- (BOOL)prefersStatusBarHidden
{
    return true;
}

- (void)signupPressed
{
    NSString *username = [((SignupView *)self.view).usernameField.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *email = ((SignupView *)self.view).emailField.text;
    NSString *password = ((SignupView *)self.view).passwordField.text;
    NSString *repeatPassword = ((SignupView *)self.view).repeatPasswordField.text;
    
    if(username.length < 5) {
        [self errorWithSignupData:@"Username needs to be longer and cannot use spaces!"];
        return;
    } else if(![[NSPredicate predicateWithFormat:@"SELF MATCHES %@", @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}"] evaluateWithObject:email] ) {
        [self errorWithSignupData:@"Your email is invalid!"];
        return;
    } else if (password.length < 5) {
        [self errorWithSignupData:@"Password is too short!"];
        return;
    } else if (![password isEqualToString:repeatPassword]) {
        [self errorWithSignupData:@"Passwords don't match!"];
        return;
    } else if(!profileImage) {
        [self errorWithSignupData:@"Please select a profile picture!"];
        return;
    }
    
    //Create Params
    NSDictionary *params = @{@"username": username,
                             @"email": email,
                             @"password": password,//Encrypt this but for now send as plain text TODO
                             @"profileImage": [UIImageJPEGRepresentation(profileImage, 1) base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithCarriageReturn]
                             };
    
    username = nil;
    email = nil;
    password = nil;
    repeatPassword = nil;
    
   __block UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        indicator.affX = (self.view.affWidth - indicator.affWidth)/2;
        indicator.affY = (self.view.affHeight - indicator.affHeight)/2;
        [self.view bringSubviewToFront:((SignupView *)self.view).overlayView];
        [UIView animateWithDuration:0.4f animations:^(){
            ((SignupView *)self.view).overlayView.alpha = 0.5f;
        }];
        [self.view addSubview:indicator];
        [indicator startAnimating];

    __block SignupViewController *tempSelf = self;
    
    AFFNRequest *request = [AFFNRequest requestWithConnectionType:kAFFNPost andURL:[BASE_URL stringByAppendingString:@"/signup"] andParams:params withCompletion:^(AFFNCallbackObject *result){
        [indicator stopAnimating];
        destroyAndRemove(indicator);
        [tempSelf.view sendSubviewToBack:((SignupView *)tempSelf.view).overlayView];
        [UIView animateWithDuration:0.4f animations:^(){
            ((SignupView *)tempSelf.view).overlayView.alpha = 0;
        } completion:^(BOOL done){
            //maybe put an alert displaying a successful signup or that they need to check their email for validation
            [tempSelf dismissViewControllerAnimated:true completion:nil];
            tempSelf = nil;
        }];
    } andFailure:^(NSError *error){
        [indicator stopAnimating];
        destroyAndRemove(indicator);
        [tempSelf errorWithSignupData:error.localizedDescription];
        [tempSelf.view sendSubviewToBack:((SignupView *)tempSelf.view).overlayView];
        [UIView animateWithDuration:0.4f animations:^(){
            ((SignupView *)tempSelf.view).overlayView.alpha = 0;
        } completion:^(BOOL done){
            [tempSelf.navigationController setNavigationBarHidden:false animated:true];
            [((SignupView *)tempSelf.view).scrollView setContentOffset:CGPointMake(0, -44) animated:true];
            tempSelf = nil;
        }];
    }];
    
    //If the data gets through the checks it is sent to the server
    [[AFFNManager sharedManager] addNetworkOperation:request];
    [self.navigationController setNavigationBarHidden:true animated:true];
}

- (void)errorWithSignupData:(NSString *)message
{
    [[VDDialogViewController sharedManager] addAndOpenViewWithViewController:self andSize:CGSizeMake(270, 189) andTitle:@"Signup Error" andText:message andButtons:[NSArray arrayWithObject:@"Okay"]];
}

- (void)profileImagePressed
{
    UIImagePickerController *profileImagePicker = [[UIImagePickerController alloc] init];
    profileImagePicker.delegate = self;
    profileImagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;//UIImagePickerControllerSourceTypeCamera;
    profileImagePicker.allowsEditing = true;
    [self presentViewController:profileImagePicker animated:true completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    picker.delegate = nil;
    
    //create a scaled down, cropped version. 160px X 160px should be okay
    UIImage *newImage = info[UIImagePickerControllerEditedImage] ? info[UIImagePickerControllerEditedImage] : info[UIImagePickerControllerOriginalImage];
    
//    NSLog(@"width: %f height:%f",newImage.size.width, newImage.size.height);
    
    //This will become global as I will use this logic elsewhere
    
    int newSize = 160;
    
    //THIS IS IF I WANT ASPECT RATIO RETAINED, WHICH I DON'T WANT IN THIS CASE. I WANT A SQUARE IMAGE AS THAT LOOKS THE BEST
//    //check aspect ratios
//    float xRatio = newSize / newImage.size.width;
//    float yRatio = newSize / newImage.size.height;
//    //Create new frame for the image
//    CGRect newFrame;
//    if(xRatio > yRatio)
//        newFrame = CGRectMake(0, 0, newImage.size.width * yRatio, newImage.size.height * yRatio);
//    else
//        newFrame = CGRectMake(0, 0, newImage.size.width * xRatio, newImage.size.height * xRatio);
        //check aspect ratios
        float xRatio = newSize / newImage.size.width;
        float yRatio = newSize / newImage.size.height;
        //Create new frame for the image
        CGRect newFrame;
        if(xRatio > yRatio)
            newFrame = CGRectMake(0, 0, newImage.size.width * xRatio, newImage.size.height * xRatio);
        else
            newFrame = CGRectMake(0, 0, newImage.size.width * yRatio, newImage.size.height * yRatio);
    
    //Create new image
    UIGraphicsBeginImageContext(CGSizeMake(newSize, newSize));
    
    [newImage drawInRect:newFrame];
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
//    NSLog(@"width: %f height:%f",newImage.size.width, newImage.size.height);
    [((SignupView *)self.view).profileImage setImage:newImage forState:UIControlStateNormal];
    [((SignupView *)self.view).profileImage setImage:newImage forState:UIControlStateHighlighted];
    
    
    profileImage = [newImage copy];
    
    newImage = nil;
    
    [picker dismissViewControllerAnimated:true completion:nil];
    
}

@end
