//
//  VDDialogViewController.h
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-11.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VDDialog.h"

@protocol VDVDDialogViewDelegate <NSObject>

@optional
- (void)buttonClickedAtIndex:(int)index andTextData:(NSString *)ltextData;

@end

@interface VDDialogViewController : UIViewController
{
    VDDialog *view;
}
+ (VDDialogViewController *)sharedManager;
- (void)addAndOpenViewWithViewController:(UIViewController *)vc andSize:(CGSize)lsize andTitle:(NSString *)ltitle andText:(NSString *)ltext andButtons:(NSArray *)lbuttons;
- (void)openViewWithSize:(CGSize)lsize andTitle:(NSString *)ltitle andText:(NSString *)ltext andButtons:(NSArray *)lbuttons;



@property(weak, nonatomic)UIViewController<VDVDDialogViewDelegate> *delegate;
@property(strong, nonatomic)UIView *blocker;
@end