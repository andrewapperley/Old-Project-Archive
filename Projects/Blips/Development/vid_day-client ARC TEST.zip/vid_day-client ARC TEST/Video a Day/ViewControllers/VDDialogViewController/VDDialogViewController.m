//
//  VDDialogViewController.m
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-11.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import "VDDialogViewController.h"


@interface VDDialogViewController ()

@end

@implementation VDDialogViewController

+ (VDDialogViewController *)sharedManager
{
    static dispatch_once_t onceToken;
    static VDDialogViewController *_sharedManager = nil;
    
    dispatch_once(&onceToken, ^{
        _sharedManager = [VDDialogViewController new];
        _sharedManager.blocker = [[UIView alloc] initWithFrame:_sharedManager.view.frame];
        _sharedManager.blocker.backgroundColor = [UIColor blackColor];
        [_sharedManager.view addSubview:_sharedManager.blocker];
    });
    
	return _sharedManager;
}

- (void)openViewWithSize:(CGSize)lsize andTitle:(NSString *)ltitle andText:(NSString *)ltext andButtons:(NSArray *)lbuttons
{
    self.blocker.alpha = 0;
    view = [[VDDialog alloc] initWithSize:lsize andTitle:ltitle andText:ltext andButtons:lbuttons];
    CENTER_OBJECT(view, self.view);
    view.alpha = 0;
    view.transform = CGAffineTransformScale(view.transform, 2.0, 2.0);
    self.view.frame = CGRectMake(0, 0, MAIN_SCREEN_SIZE.width, MAIN_SCREEN_SIZE.height);
    [self.view addSubview:view];
    [UIView animateWithDuration:0.5f animations:^(){
        self.blocker.alpha = 0.3;
    } completion:^(BOOL done){
        if(done)
        {
            [UIView animateWithDuration:0.5 animations:^(){
                view.transform = CGAffineTransformScale(view.transform, 1.0 / 2, 1.0 / 2);
                view.alpha = 1;
            }];
        }
    }];
    
    [[view evtButtonPressed] addHandlerOneTime:AFFHandler(@selector(buttonClickedAtIndex:))];
    
   
}

- (void)addAndOpenViewWithViewController:(UIViewController *)vc andSize:(CGSize)lsize andTitle:(NSString *)ltitle andText:(NSString *)ltext andButtons:(NSArray *)lbuttons
{
    self.view.userInteractionEnabled = true;
    self.delegate = (UIViewController<VDVDDialogViewDelegate> *)vc;
    [vc addChildViewController:[VDDialogViewController sharedManager]];
    [self openViewWithSize:lsize andTitle:ltitle andText:ltext andButtons:lbuttons];
    [vc.view addSubview:self.view];
}

- (void)buttonClickedAtIndex:(AFFEvent *)event
{
    if([self.delegate respondsToSelector:@selector(buttonClickedAtIndex:andTextData:)])
        [self.delegate buttonClickedAtIndex:[[event.data objectForKey:@"buttonIndex"] intValue] andTextData:[event.data objectForKey:@"textInput"]];
    [self closeView];
}

- (void)closeView
{
    [UIView animateWithDuration:0.5 animations:^(){
        view.transform = CGAffineTransformScale(view.transform, 0.8, 0.8);
        view.alpha = 0;
    } completion:^(BOOL done){
        if(done) {
            [UIView animateWithDuration:0.5 animations:^(){
                self.blocker.alpha = 0;
            }];
            [view removeFromSuperview];
            view = nil;
            [self removeFromParentViewController];
            self.delegate = nil;
            self.view.userInteractionEnabled = false;
        }
    }];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

@end
