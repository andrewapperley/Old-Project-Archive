//
//  Constants.m
//  Video a Day
//
//  Created by Andrew Apperley on 2013-09-14.
//  Copyright (c) 2013 AFApps. All rights reserved.
//

#import "Constants.h"

NSString *const MAIN_FONT = @"HelveticaNeue-UltraLight";
NSString *const BOLD_FONT = @"HelveticaNeue-Light";
NSString *const BASE_URL = @"http://192.168.0.14:8080/";
int HEADER_HEIGHT = 88;